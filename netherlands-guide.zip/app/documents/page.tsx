"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type DocumentStatus = "yes" | "no";

type Profile = {
  documents?: string[];
  name?: string;
};

type DocumentItem = {
  id: string;
  icon: string;
  title: string;
  description: string;
  yesLabel: string;
  noLabel: string;
};

const documentItems: DocumentItem[] = [
  {
    id: "bsn",
    icon: "🔢",
    title: "BSN",
    description:
      "Your personal citizen service number used for many Dutch government services.",
    yesLabel: "You have your BSN",
    noLabel: "Learn how to get a BSN",
  },
  {
    id: "digid",
    icon: "🪪",
    title: "DigiD",
    description:
      "Your digital identity for logging in to many Dutch government and public services.",
    yesLabel: "You have DigiD",
    noLabel: "Check if you can apply",
  },
  {
    id: "residence",
    icon: "🛂",
    title: "Residence document",
    description:
      "Your residence document or permit showing your right to stay in the Netherlands.",
    yesLabel: "You have a residence document",
    noLabel: "Learn what you need",
  },
  {
    id: "municipality",
    icon: "🏛️",
    title: "Municipality registration",
    description:
      "Your registration with the Dutch municipality where you live.",
    yesLabel: "You are registered",
    noLabel: "Learn how to register",
  },
  {
    id: "letters",
    icon: "📬",
    title: "Official letters",
    description:
      "Letters from Dutch government organisations can contain important information and deadlines.",
    yesLabel: "You receive official letters",
    noLabel: "Learn how they work",
  },
];

function getStatus(
  selectedDocuments: string[],
  id: string
): DocumentStatus {
  if (selectedDocuments.includes(id)) {
    return "yes";
  }

  return "no";
}

export default function DocumentsPage() {
  const router = useRouter();

  const [profile, setProfile] = useState<Profile | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(
        "netherlandsGuideProfile"
      );

      if (saved) {
        const parsed = JSON.parse(saved) as Profile;
        setProfile(parsed);
      }
    } catch {
      setProfile(null);
    }

    setLoaded(true);
  }, []);

  if (!loaded) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-50">
        <p className="text-slate-500">
          Loading your documents...
        </p>
      </main>
    );
  }

  const selectedDocuments = profile?.documents ?? [];

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">

      {/* HEADER */}
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-5 py-4 sm:px-6">

          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-50 text-2xl">
              🇳🇱
            </div>

            <div>
              <h1 className="font-bold">
                Netherlands Guide
              </h1>

              <p className="text-xs text-slate-500">
                Your guide to life in the Netherlands
              </p>
            </div>
          </div>

        </div>
      </header>

      <section className="mx-auto max-w-5xl px-5 py-8 sm:px-6 sm:py-10">

        {/* BACK BUTTON — TOP LEFT */}
        <button
          type="button"
          onClick={() => router.push("/dashboard")}
          className="mb-7 inline-flex items-center rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:border-orange-300 hover:bg-orange-50"
        >
          ← Back to Dashboard
        </button>

        {/* PAGE INTRO */}
        <div className="mb-8">
          <p className="text-sm font-bold uppercase tracking-[0.18em] text-orange-500">
            Your documents
          </p>

          <h1 className="mt-2 text-4xl font-black">
            {profile?.name
              ? `${profile.name}'s documents`
              : "Your documents"}
          </h1>

          <p className="mt-3 max-w-2xl leading-7 text-slate-500">
            We use the information you gave us when creating
            your profile. This helps us avoid showing you tasks
            for things you already have.
          </p>
        </div>

        {/* DOCUMENT CARDS */}
        <div className="grid gap-4 md:grid-cols-2">
          {documentItems.map((document) => {
            const status = getStatus(
              selectedDocuments,
              document.id
            );

            const hasDocument = status === "yes";

            return (
              <button
                key={document.id}
                type="button"
                onClick={() =>
                  router.push(
                    `/guide?topic=${document.id}`
                  )
                }
                className={`rounded-3xl border p-6 text-left transition hover:-translate-y-0.5 hover:shadow-md ${
                  hasDocument
                    ? "border-green-200 bg-green-50"
                    : "border-orange-200 bg-white"
                }`}
              >
                <div className="flex items-start justify-between gap-4">

                  <div className="text-5xl">
                    {document.icon}
                  </div>

                  <div
                    className={`rounded-full px-3 py-1 text-xs font-bold ${
                      hasDocument
                        ? "bg-green-100 text-green-700"
                        : "bg-orange-100 text-orange-700"
                    }`}
                  >
                    {hasDocument
                      ? "✓ DONE"
                      : "ACTION NEEDED"}
                  </div>

                </div>

                <h2 className="mt-5 text-2xl font-bold">
                  {document.title}
                </h2>

                <p className="mt-2 leading-relaxed text-slate-600">
                  {document.description}
                </p>

                <div
                  className={`mt-5 rounded-2xl p-4 font-semibold ${
                    hasDocument
                      ? "bg-white text-green-700"
                      : "bg-orange-500 text-white"
                  }`}
                >
                  {hasDocument
                    ? `✅ ${document.yesLabel}`
                    : `→ ${document.noLabel}`}
                </div>

                <div className="mt-4 text-sm font-semibold text-slate-500">
                  Open guide →
                </div>
              </button>
            );
          })}
        </div>

        {/* PROFILE CONNECTION */}
        <div className="mt-8 rounded-3xl bg-white p-6 shadow-sm">
          <div className="flex items-start gap-4">

            <div className="text-3xl">
              💡
            </div>

            <div>
              <h2 className="text-xl font-bold">
                Your documents follow your profile
              </h2>

              <p className="mt-2 leading-relaxed text-slate-500">
                If you get a new document later, you can update
                your profile. Your document status will then
                change automatically.
              </p>

              <button
                type="button"
                onClick={() =>
                  router.push("/onboarding")
                }
                className="mt-4 rounded-xl bg-slate-100 px-5 py-3 font-semibold transition hover:bg-slate-200"
              >
                ⚙️ Edit my profile
              </button>
            </div>

          </div>
        </div>

        {/* POSTCODE FINDER */}
        <div className="mt-8 rounded-3xl bg-blue-50 p-6">

          <div className="text-4xl">
            📍
          </div>

          <h2 className="mt-4 text-2xl font-bold text-blue-900">
            Need to find your postcode?
          </h2>

          <p className="mt-2 leading-relaxed text-blue-800">
            You don't need to know your postcode by memory.
            Enter your address and get help finding the
            correct postcode.
          </p>

          <p className="mt-3 text-sm text-blue-700">
            Your address will not be saved by this feature.
          </p>

          <button
            type="button"
            onClick={() =>
              router.push(
                "/chat?question=I need help finding the postcode for my address in the Netherlands. Please explain what information I need to enter. Do not save my address."
              )
            }
            className="mt-5 rounded-xl bg-blue-600 px-5 py-3 font-semibold text-white transition hover:bg-blue-700"
          >
            📍 Find my postcode
          </button>

        </div>

        {/* AI HELPER */}
        <div className="mt-8 rounded-3xl bg-indigo-50 p-7">

          <div className="text-4xl">
            🤖
          </div>

          <h2 className="mt-4 text-2xl font-bold text-slate-900">
            Don't understand?
          </h2>

          <p className="mt-2 leading-relaxed text-slate-600">
            Ask the AI Guide for a simple explanation about
            your documents or what you should do next.
          </p>

          <button
            type="button"
            onClick={() =>
              router.push(
                "/chat?question=I am not sure which Dutch government document or service I need. Ask me simple questions one at a time and guide me toward the correct official next step. Never ask me for passwords, PINs, or secret login information."
              )
            }
            className="mt-5 rounded-xl bg-indigo-600 px-6 py-3 font-semibold text-white transition hover:bg-indigo-700"
          >
            🤖 Ask AI →
          </button>

        </div>

        {/* BOTTOM BACK BUTTON */}
        <button
          type="button"
          onClick={() => router.push("/dashboard")}
          className="mt-10 w-full rounded-2xl border border-slate-200 bg-white px-5 py-4 text-center font-bold text-slate-700 shadow-sm transition hover:border-orange-300 hover:bg-orange-50"
        >
          ← Back to Dashboard
        </button>

      </section>
    </main>
  );
}