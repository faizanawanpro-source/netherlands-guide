"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Profile = {
  name?: string;
  age?: string;
  profile?: string;
  city?: string;
  language?: string;
};

type AIResponse = {
  reply?: string;
  destination?: string;
  error?: string;
};

export default function VoicePage() {
  const router = useRouter();

  const [profile, setProfile] = useState<Profile>({});
  const [recording, setRecording] = useState(false);
  const [processing, setProcessing] = useState(false);

  const [transcript, setTranscript] = useState("");
  const [reply, setReply] = useState("");
  const [error, setError] = useState("");

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // ============================================================
  // LOAD PROFILE
  // ============================================================

  useEffect(() => {
    try {
      const savedProfile = localStorage.getItem(
        "netherlandsGuideProfile"
      );

      if (savedProfile) {
        setProfile(JSON.parse(savedProfile));
      }
    } catch (error) {
      console.error("Could not load profile:", error);
    }
  }, []);

  // ============================================================
  // LANGUAGE
  // ============================================================

  function getSpeechLanguage(language?: string) {
    switch (language) {
      case "Nederlands":
        return "nl-NL";

      case "اردو":
        return "ur-PK";

      case "हिन्दी":
        return "hi-IN";

      case "ਪੰਜਾਬੀ":
        return "pa-IN";

      case "العربية":
        return "ar-SA";

      case "Türkçe":
        return "tr-TR";

      case "English":
      default:
        return "en-US";
    }
  }

  // ============================================================
  // SPEAK AI RESPONSE
  // ============================================================

  function speakReply(text: string) {
    if (!("speechSynthesis" in window)) {
      console.warn(
        "Speech synthesis is not supported on this device."
      );

      return;
    }

    window.speechSynthesis.cancel();

    const utterance =
      new SpeechSynthesisUtterance(text);

    utterance.lang = getSpeechLanguage(
      profile.language
    );

    utterance.rate = 0.95;
    utterance.pitch = 1;
    utterance.volume = 1;

    utterance.onstart = () => {
      console.log("AI started speaking.");
    };

    utterance.onend = () => {
      console.log("AI finished speaking.");
    };

    utterance.onerror = (event) => {
      console.error(
        "Speech synthesis error:",
        event
      );
    };

    window.speechSynthesis.speak(utterance);
  }

  // ============================================================
  // START RECORDING
  // ============================================================

  async function startRecording() {
    setError("");
    setReply("");
    setTranscript("");

    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error(
          "Microphone access is not available on this device."
        );
      }

      const stream =
        await navigator.mediaDevices.getUserMedia({
          audio: true,
        });

      let mimeType = "";

      if (
        MediaRecorder.isTypeSupported(
          "audio/mp4"
        )
      ) {
        mimeType = "audio/mp4";
      } else if (
        MediaRecorder.isTypeSupported(
          "audio/webm;codecs=opus"
        )
      ) {
        mimeType = "audio/webm;codecs=opus";
      } else if (
        MediaRecorder.isTypeSupported(
          "audio/webm"
        )
      ) {
        mimeType = "audio/webm";
      }

      const recorder = mimeType
        ? new MediaRecorder(stream, {
            mimeType,
          })
        : new MediaRecorder(stream);

      audioChunksRef.current = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(
            event.data
          );
        }
      };

      recorder.onerror = (event) => {
        console.error(
          "MediaRecorder error:",
          event
        );

        setError(
          "There was a problem recording your voice."
        );

        setRecording(false);
      };

      recorder.onstop = async () => {
        stream
          .getTracks()
          .forEach((track) => track.stop());

        const actualType =
          recorder.mimeType ||
          "audio/mp4";

        const audioBlob = new Blob(
          audioChunksRef.current,
          {
            type: actualType,
          }
        );

        console.log(
          "Recording finished:",
          actualType,
          audioBlob.size
        );

        await transcribeAudio(
          audioBlob
        );
      };

      mediaRecorderRef.current = recorder;

      recorder.start();

      setRecording(true);

      console.log(
        "Recording started:",
        recorder.mimeType
      );
    } catch (error) {
      console.error(
        "Microphone error:",
        error
      );

      setError(
        error instanceof Error
          ? error.message
          : "Could not access the microphone."
      );

      setRecording(false);
    }
  }

  // ============================================================
  // STOP RECORDING
  // ============================================================

  function stopRecording() {
    const recorder =
      mediaRecorderRef.current;

    if (
      recorder &&
      recorder.state !== "inactive"
    ) {
      recorder.stop();
    }

    setRecording(false);
  }

  // ============================================================
  // TRANSCRIBE AUDIO
  // ============================================================

  async function transcribeAudio(
    audioBlob: Blob
  ) {
    setProcessing(true);
    setError("");

    try {
      let extension = "m4a";

      if (
        audioBlob.type.includes("webm")
      ) {
        extension = "webm";
      } else if (
        audioBlob.type.includes("mp4")
      ) {
        extension = "m4a";
      }

      const audioFile = new File(
        [audioBlob],
        `voice.${extension}`,
        {
          type:
            audioBlob.type ||
            "audio/mp4",
        }
      );

      const formData = new FormData();

      formData.append(
        "audio",
        audioFile
      );

      console.log(
        "Sending audio for transcription..."
      );

      const response = await fetch(
        "/api/transcribe",
        {
          method: "POST",
          body: formData,
        }
      );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.error ||
            "Transcription failed."
        );
      }

      const text =
        data.text?.trim();

      if (!text) {
        throw new Error(
          "I couldn't understand what you said."
        );
      }

      console.log(
        "You said:",
        text
      );

      setTranscript(text);

      await askAI(text);
    } catch (error) {
      console.error(
        "Voice processing error:",
        error
      );

      setError(
        error instanceof Error
          ? error.message
          : "Something went wrong while processing your voice."
      );
    } finally {
      setProcessing(false);
    }
  }

  // ============================================================
  // ASK AI
  // ============================================================

  async function askAI(
    message: string
  ) {
    try {
      console.log(
        "Sending message to Netherlands Guide AI..."
      );

      const response = await fetch(
        "/api/chat",
        {
          method: "POST",
          headers: {
            "Content-Type":
              "application/json",
          },
          body: JSON.stringify({
            message,
            profile,
          }),
        }
      );

      const data: AIResponse =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data.error ||
            "AI request failed."
        );
      }

      const aiReply =
        data.reply?.trim() || "";

      if (!aiReply) {
        throw new Error(
          "The AI returned an empty response."
        );
      }

      console.log(
        "AI reply:",
        aiReply
      );

      setReply(aiReply);

      // ========================================================
      // SPEAK THE AI RESPONSE
      // ========================================================

      speakReply(aiReply);

      // ========================================================
      // NAVIGATION
      // ========================================================

      if (
        data.destination &&
        typeof data.destination ===
          "string"
      ) {
        console.log(
          "Navigating to:",
          data.destination
        );

        setTimeout(() => {
          router.push(
            data.destination as string
          );
        }, 2500);
      }
    } catch (error) {
      console.error(
        "AI error:",
        error
      );

      throw error;
    }
  }

  // ============================================================
  // STOP SPEAKING
  // ============================================================

  function stopSpeaking() {
    if (
      "speechSynthesis" in window
    ) {
      window.speechSynthesis.cancel();
    }
  }

  // ============================================================
  // UI
  // ============================================================

  return (
    <main className="min-h-screen bg-slate-950 text-white">

      {/* HEADER */}

      <header className="border-b border-white/10">

        <div className="mx-auto flex max-w-4xl items-center justify-between px-6 py-5">

          <button
            type="button"
            onClick={() =>
              router.push("/dashboard")
            }
            className="font-bold text-slate-300 transition hover:text-white"
          >
            ← Dashboard
          </button>

          <div className="font-black">
            🇳🇱 Netherlands Guide
          </div>

        </div>

      </header>


      {/* MAIN */}

      <section className="mx-auto flex min-h-[calc(100vh-80px)] max-w-3xl flex-col items-center justify-center px-6 py-12">

        <p className="text-sm font-black uppercase tracking-[0.25em] text-orange-400">
          AI Voice Assistant
        </p>


        <h1 className="mt-4 text-center text-4xl font-black sm:text-6xl">
          Just tell me what you need.
        </h1>


        <p className="mt-5 max-w-xl text-center text-lg leading-8 text-slate-400">
          Speak naturally. I&apos;ll understand your
          question, answer in your preferred language,
          and help you find the right part of the app.
        </p>


        {/* MICROPHONE */}

        <button
          type="button"
          onClick={
            processing
              ? undefined
              : recording
              ? stopRecording
              : startRecording
          }
          disabled={processing}
          className={`mt-12 flex h-40 w-40 items-center justify-center rounded-full text-6xl shadow-2xl transition ${
            recording
              ? "animate-pulse bg-red-500"
              : processing
              ? "cursor-wait bg-indigo-600"
              : "bg-orange-500 hover:scale-105 hover:bg-orange-600"
          }`}
        >
          {recording
            ? "⏹️"
            : processing
            ? "🤖"
            : "🎤"}
        </button>


        {/* STATUS */}

        <div className="mt-8 text-center">

          {recording && (
            <div>
              <p className="font-bold text-red-400">
                🔴 Listening...
              </p>

              <p className="mt-1 text-sm text-slate-500">
                Tap the button when you&apos;re finished.
              </p>
            </div>
          )}


          {processing && (
            <div>
              <p className="font-bold text-indigo-400">
                🤖 Understanding you...
              </p>

              <p className="mt-1 text-sm text-slate-500">
                Please wait a moment.
              </p>
            </div>
          )}


          {!recording &&
            !processing &&
            !reply && (
              <p className="text-slate-500">
                Tap 🎤 and start speaking
              </p>
            )}

        </div>


        {/* TRANSCRIPT */}

        {transcript && (
          <div className="mt-10 w-full rounded-3xl border border-white/10 bg-white/5 p-6">

            <p className="text-xs font-black uppercase tracking-widest text-slate-500">
              You said
            </p>

            <p className="mt-3 text-lg font-semibold">
              “{transcript}”
            </p>

          </div>
        )}


        {/* AI RESPONSE */}

        {reply && (
          <div className="mt-5 w-full rounded-3xl border border-indigo-500/20 bg-indigo-500/10 p-6">

            <div className="flex items-center justify-between gap-4">

              <p className="text-xs font-black uppercase tracking-widest text-indigo-400">
                🤖 Netherlands Guide AI
              </p>

              <button
                type="button"
                onClick={stopSpeaking}
                className="rounded-xl bg-white/10 px-3 py-2 text-xs font-bold transition hover:bg-white/20"
              >
                🔇 Stop
              </button>

            </div>

            <p className="mt-3 text-lg leading-8">
              {reply}
            </p>

          </div>
        )}


        {/* ERROR */}

        {error && (
          <div className="mt-6 w-full rounded-2xl border border-red-500/30 bg-red-500/10 px-5 py-4 text-center text-red-300">
            {error}
          </div>
        )}


        {/* PROFILE LANGUAGE */}

        <div className="mt-8 text-center text-xs text-slate-600">

          AI voice language:{" "}

          <span className="font-bold text-slate-500">
            {profile.language ||
              "English"}
          </span>

        </div>

      </section>

    </main>
  );
}