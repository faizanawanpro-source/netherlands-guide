"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

import {
  supportedLanguages,
  type SupportedLanguage,
} from "@/lib/translations";

import { useLanguage } from "@/components/LanguageProvider";

type ProfileType =
  | "refugee"
  | "student"
  | "tourist"
  | "resident";

type FamilyMember =
  | "partner"
  | "children"
  | "parents"
  | "siblings"
  | "otherFamily";

type DocumentType =
  | "bsn"
  | "digid"
  | "residence"
  | "municipality"
  | "officialLetters";

type ProfileData = {
  name: string;
  age: string;
  profile: ProfileType;
  city: string;
  language: SupportedLanguage;
  hasFamily: "yes" | "no" | "";
  familyMembers: FamilyMember[];
  documents: DocumentType[];
};

const cities = [
  "Amsterdam",
  "Rotterdam",
  "The Hague",
  "Utrecht",
  "Eindhoven",
  "Groningen",
  "Tilburg",
  "Almere",
  "Breda",
  "Nijmegen",
  "Arnhem",
  "Haarlem",
  "Amersfoort",
  "Apeldoorn",
  "Hilversum",
  "Leiden",
  "Delft",
  "Maastricht",
  "Zwolle",
  "Other",
];

const familyOptions: {
  id: FamilyMember;
  icon: string;
  labelKey: FamilyMember;
}[] = [
  {
    id: "partner",
    icon: "❤️",
    labelKey: "partner",
  },
  {
    id: "children",
    icon: "👶",
    labelKey: "children",
  },
  {
    id: "parents",
    icon: "👨‍👩‍👦",
    labelKey: "parents",
  },
  {
    id: "siblings",
    icon: "🧑‍🤝‍🧑",
    labelKey: "siblings",
  },
  {
    id: "otherFamily",
    icon: "👪",
    labelKey: "otherFamily",
  },
];

const documentOptions: {
  id: DocumentType;
  icon: string;
  titleKey:
    | "bsnTitle"
    | "digidTitle"
    | "residenceTitle"
    | "municipalityTitle"
    | "officialLettersTitle";
  descriptionKey:
    | "bsnDescription"
    | "digidDescription"
    | "residenceDescription"
    | "municipalityDescription"
    | "officialLettersDescription";
}[] = [
  {
    id: "bsn",
    icon: "🪪",
    titleKey: "bsnTitle",
    descriptionKey: "bsnDescription",
  },
  {
    id: "digid",
    icon: "🔐",
    titleKey: "digidTitle",
    descriptionKey: "digidDescription",
  },
  {
    id: "residence",
    icon: "📑",
    titleKey: "residenceTitle",
    descriptionKey: "residenceDescription",
  },
  {
    id: "municipality",
    icon: "🏛️",
    titleKey: "municipalityTitle",
    descriptionKey: "municipalityDescription",
  },
  {
    id: "officialLetters",
    icon: "✉️",
    titleKey: "officialLettersTitle",
    descriptionKey:
      "officialLettersDescription",
  },
];

export default function OnboardingPage() {
  const router = useRouter();
  const { language, setLanguage, t } =
    useLanguage();

  const [loaded, setLoaded] =
    useState(false);

  const [name, setName] =
    useState("");

  const [age, setAge] =
    useState("");

  const [profile, setProfile] =
    useState<ProfileType | "">("");

  const [city, setCity] =
    useState("");

  const [hasFamily, setHasFamily] =
    useState<"yes" | "no" | "">("");

  const [familyMembers, setFamilyMembers] =
    useState<FamilyMember[]>([]);

  const [documents, setDocuments] =
    useState<DocumentType[]>([]);

  /*
   * ============================================================
   * LOAD SAVED PROFILE
   * ============================================================
   */

  useEffect(() => {
    try {
      const savedProfile =
        localStorage.getItem(
          "netherlandsGuideProfile"
        );

      if (savedProfile) {
        const parsed =
          JSON.parse(savedProfile);

        if (
          typeof parsed.name === "string"
        ) {
          setName(parsed.name);
        }

        if (
          typeof parsed.age === "string"
        ) {
          setAge(parsed.age);
        }

        if (
          parsed.profile ===
            "refugee" ||
          parsed.profile ===
            "student" ||
          parsed.profile ===
            "tourist" ||
          parsed.profile ===
            "resident"
        ) {
          setProfile(parsed.profile);
        }

        if (
          typeof parsed.city === "string"
        ) {
          setCity(parsed.city);
        }

        if (
          parsed.hasFamily === "yes" ||
          parsed.hasFamily === "no"
        ) {
          setHasFamily(
            parsed.hasFamily
          );
        }

        if (
          Array.isArray(
            parsed.familyMembers
          )
        ) {
          setFamilyMembers(
            parsed.familyMembers.filter(
              (item: string) =>
                familyOptions.some(
                  (option) =>
                    option.id === item
                )
            )
          );
        }

        if (
          Array.isArray(
            parsed.documents
          )
        ) {
          setDocuments(
            parsed.documents.filter(
              (item: string) =>
                documentOptions.some(
                  (option) =>
                    option.id === item
                )
            )
          );
        }
      }

      const savedLanguage =
        localStorage.getItem(
          "netherlandsGuideLanguage"
        );

      if (savedLanguage) {
        const validLanguage =
          supportedLanguages.find(
            (item) =>
              item.code ===
              savedLanguage
          );

        if (validLanguage) {
          setLanguage(
            validLanguage.code
          );
        }
      }
    } catch (error) {
      console.error(
        "Could not load saved profile:",
        error
      );
    } finally {
      setLoaded(true);
    }
  }, [setLanguage]);

  /*
   * ============================================================
   * PROFILE HELPERS
   * ============================================================
   */

  const isTourist =
    profile === "tourist";

  const isStudent =
    profile === "student";

  const isNewcomer =
    profile === "refugee";

  const isResident =
    profile === "resident";

  /*
   * ============================================================
   * VALIDATION
   * ============================================================
   */

  const baseRequirements =
    name.trim() !== "" &&
    age.trim() !== "" &&
    profile !== "";

  const touristRequirements =
    isTourist;

  const studentRequirements =
    isStudent &&
    city !== "";

  const newcomerRequirements =
    isNewcomer &&
    city !== "" &&
    hasFamily !== "" &&
    documents.length > 0 &&
    (
      hasFamily === "no" ||
      familyMembers.length > 0
    );

  const residentRequirements =
    isResident &&
    city !== "" &&
    hasFamily !== "" &&
    documents.length > 0 &&
    (
      hasFamily === "no" ||
      familyMembers.length > 0
    );

  const canContinue =
    baseRequirements &&
    (
      touristRequirements ||
      studentRequirements ||
      newcomerRequirements ||
      residentRequirements
    );

  /*
   * ============================================================
   * PROFILE CHANGE
   * ============================================================
   */

  function handleProfileChange(
    selectedProfile: ProfileType
  ) {
    setProfile(selectedProfile);

    setCity("");
    setHasFamily("");
    setFamilyMembers([]);
    setDocuments([]);
  }

  /*
   * ============================================================
   * FAMILY
   * ============================================================
   */

  function toggleFamily(
    id: FamilyMember
  ) {
    setFamilyMembers(
      (current) =>
        current.includes(id)
          ? current.filter(
              (item) =>
                item !== id
            )
          : [...current, id]
    );
  }

  /*
   * ============================================================
   * DOCUMENTS
   * ============================================================
   */

  function toggleDocument(
    id: DocumentType
  ) {
    setDocuments(
      (current) =>
        current.includes(id)
          ? current.filter(
              (item) =>
                item !== id
            )
          : [...current, id]
    );
  }

  /*
   * ============================================================
   * LANGUAGE
   * ============================================================
   */

  function handleLanguageChange(
    newLanguage: SupportedLanguage
  ) {
    setLanguage(newLanguage);
  }

  /*
   * ============================================================
   * SAVE
   * ============================================================
   */

  function handleContinue() {
    if (!canContinue) {
      return;
    }

    const profileData: ProfileData = {
      name: name.trim(),
      age: age.trim(),
      profile: profile as ProfileType,
      city,
      language,

      hasFamily:
        isNewcomer ||
        isResident
          ? hasFamily
          : "",

      familyMembers:
        isNewcomer ||
        isResident
          ? familyMembers
          : [],

      documents:
        isNewcomer ||
        isResident
          ? documents
          : [],
    };

    try {
      localStorage.setItem(
        "netherlandsGuideProfile",
        JSON.stringify(
          profileData
        )
      );

      localStorage.setItem(
        "netherlandsGuideLanguage",
        language
      );

      localStorage.setItem(
        "netherlandsGuideOnboardingComplete",
        "true"
      );

      router.push("/dashboard");
    } catch (error) {
      console.error(
        "Could not save profile:",
        error
      );
    }
  }

  /*
   * ============================================================
   * LOADING
   * ============================================================
   */

  if (!loaded) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="text-5xl">
            🇳🇱
          </div>

          <p className="mt-4 font-bold text-slate-700">
            {t.loadingProfile}
          </p>
        </div>
      </main>
    );
  }

  /*
   * ============================================================
   * PAGE
   * ============================================================
   */

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">

      {/* HEADER */}

      <header className="border-b bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">

          <div className="flex items-center gap-3">

            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-500 text-2xl">
              🇳🇱
            </div>

            <div>
              <h1 className="font-bold">
                {t.appName}
              </h1>

              <p className="text-xs text-slate-500">
                {t.appDescription}
              </p>
            </div>

          </div>

          <span className="rounded-full bg-slate-100 px-4 py-2 text-sm font-semibold">
            {name
              ? t.editProfile
              : t.getStarted}
          </span>

        </div>
      </header>

      {/* MAIN */}

      <section className="mx-auto max-w-4xl px-6 py-10">

        <div className="rounded-3xl bg-white p-8 shadow-xl md:p-10">

          <p className="text-sm font-bold uppercase tracking-widest text-orange-500">
            {t.personalizeGuide}
          </p>

          <h2 className="mt-2 text-3xl font-black">
            {name
              ? `${t.welcomeBack}, ${name}!`
              : t.setupProfile}
          </h2>

          <p className="mt-3 text-slate-500">
            {t.profileDescription}
          </p>

          {/* NAME */}

          <div className="mt-8">
            <label className="font-bold">
              {t.nameQuestion}
            </label>

            <input
              type="text"
              value={name}
              onChange={(event) =>
                setName(
                  event.target.value
                )
              }
              placeholder={
                t.namePlaceholder
              }
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-orange-500 focus:bg-white"
            />
          </div>

          {/* AGE */}

          <div className="mt-6">
            <label className="font-bold">
              {t.ageQuestion}
            </label>

            <input
              type="number"
              min="0"
              max="120"
              value={age}
              onChange={(event) =>
                setAge(
                  event.target.value
                )
              }
              placeholder={
                t.agePlaceholder
              }
              className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-orange-500 focus:bg-white"
            />
          </div>

          {/* PROFILE */}

          <div className="mt-8">

            <h3 className="font-bold">
              {t.profileQuestion}
            </h3>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">

              {/* REFUGEE */}

              <button
                type="button"
                onClick={() =>
                  handleProfileChange(
                    "refugee"
                  )
                }
                className={`rounded-2xl border p-5 text-left transition ${
                  profile === "refugee"
                    ? "border-orange-500 bg-orange-50"
                    : "border-slate-200 hover:border-orange-300"
                }`}
              >
                <div className="text-3xl">
                  🕊️
                </div>

                <p className="mt-3 font-bold">
                  {t.refugeeTitle}
                </p>

                <p className="mt-1 text-sm text-slate-500">
                  {t.refugeeDescription}
                </p>
              </button>

              {/* STUDENT */}

              <button
                type="button"
                onClick={() =>
                  handleProfileChange(
                    "student"
                  )
                }
                className={`rounded-2xl border p-5 text-left transition ${
                  profile === "student"
                    ? "border-orange-500 bg-orange-50"
                    : "border-slate-200 hover:border-orange-300"
                }`}
              >
                <div className="text-3xl">
                  🎓
                </div>

                <p className="mt-3 font-bold">
                  {t.studentTitle}
                </p>

                <p className="mt-1 text-sm text-slate-500">
                  {t.studentDescription}
                </p>
              </button>

              {/* TOURIST */}

              <button
                type="button"
                onClick={() =>
                  handleProfileChange(
                    "tourist"
                  )
                }
                className={`rounded-2xl border p-5 text-left transition ${
                  profile === "tourist"
                    ? "border-orange-500 bg-orange-50"
                    : "border-slate-200 hover:border-orange-300"
                }`}
              >
                <div className="text-3xl">
                  ✈️
                </div>

                <p className="mt-3 font-bold">
                  {t.touristTitle}
                </p>

                <p className="mt-1 text-sm text-slate-500">
                  {t.touristDescription}
                </p>
              </button>

              {/* RESIDENT */}

              <button
                type="button"
                onClick={() =>
                  handleProfileChange(
                    "resident"
                  )
                }
                className={`rounded-2xl border p-5 text-left transition ${
                  profile === "resident"
                    ? "border-orange-500 bg-orange-50"
                    : "border-slate-200 hover:border-orange-300"
                }`}
              >
                <div className="text-3xl">
                  🏡
                </div>

                <p className="mt-3 font-bold">
                  {t.residentTitle}
                </p>

                <p className="mt-1 text-sm text-slate-500">
                  {t.residentDescription}
                </p>
              </button>

            </div>
          </div>

          {/* TOURIST MESSAGE */}

          {isTourist && (
            <div className="mt-8 rounded-2xl border border-orange-200 bg-orange-50 p-5">
              <div className="flex gap-4">

                <div className="text-3xl">
                  ✈️
                </div>

                <div>
                  <h3 className="font-black text-orange-900">
                    {t.welcomeTraveller}
                  </h3>

                  <p className="mt-1 text-sm leading-6 text-orange-800">
                    {t.travellerDescription}
                  </p>
                </div>

              </div>
            </div>
          )}

          {/* CITY */}

          {!isTourist &&
            profile !== "" && (
              <div className="mt-8">

                <label className="font-bold">
                  {isStudent
                    ? t.cityStudyQuestion
                    : t.cityQuestion}
                </label>

                <p className="mt-1 text-sm text-slate-500">
                  {t.cityDescription}
                </p>

                <select
                  value={city}
                  onChange={(event) =>
                    setCity(
                      event.target.value
                    )
                  }
                  className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-orange-500 focus:bg-white"
                >
                  <option value="">
                    {t.chooseCity}
                  </option>

                  {cities.map(
                    (item) => (
                      <option
                        key={item}
                        value={item}
                      >
                        {item}
                      </option>
                    )
                  )}
                </select>

              </div>
            )}

          {/* TOURIST DESTINATION */}

          {isTourist && (
            <div className="mt-8">

              <label className="font-bold">
                {t.touristDestination}

                <span className="ml-2 font-normal text-slate-400">
                  {t.optional}
                </span>
              </label>

              <p className="mt-1 text-sm text-slate-500">
                {t.touristDestinationDescription}
              </p>

              <select
                value={city}
                onChange={(event) =>
                  setCity(
                    event.target.value
                  )
                }
                className="mt-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 outline-none focus:border-orange-500 focus:bg-white"
              >
                <option value="">
                  {t.notDecided}
                </option>

                {cities.map(
                  (item) => (
                    <option
                      key={item}
                      value={item}
                    >
                      {item}
                    </option>
                  )
                )}
              </select>

            </div>
          )}

          {/* FAMILY */}

          {(isNewcomer ||
            isResident) && (
            <div className="mt-8">

              <h3 className="font-bold">
                {t.familyQuestion}
              </h3>

              <div className="mt-4 grid gap-3 sm:grid-cols-2">

                <button
                  type="button"
                  onClick={() =>
                    setHasFamily("yes")
                  }
                  className={`rounded-2xl border p-5 text-left transition ${
                    hasFamily === "yes"
                      ? "border-orange-500 bg-orange-50"
                      : "border-slate-200 hover:border-orange-300"
                  }`}
                >
                  <div className="text-3xl">
                    👨‍👩‍👧‍👦
                  </div>

                  <p className="mt-3 font-bold">
                    {t.familyYes}
                  </p>

                  <p className="mt-1 text-sm text-slate-500">
                    {t.familyYesDescription}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setHasFamily("no");
                    setFamilyMembers([]);
                  }}
                  className={`rounded-2xl border p-5 text-left transition ${
                    hasFamily === "no"
                      ? "border-orange-500 bg-orange-50"
                      : "border-slate-200 hover:border-orange-300"
                  }`}
                >
                  <div className="text-3xl">
                    🙋
                  </div>

                  <p className="mt-3 font-bold">
                    {t.familyNo}
                  </p>

                  <p className="mt-1 text-sm text-slate-500">
                    {t.familyNoDescription}
                  </p>
                </button>

              </div>
            </div>
          )}

          {/* FAMILY TYPES */}

          {(isNewcomer ||
            isResident) &&
            hasFamily === "yes" && (
              <div className="mt-6 rounded-2xl bg-slate-50 p-5">

                <h3 className="font-bold">
                  {t.familyWho}
                </h3>

                <p className="mt-1 text-sm text-slate-500">
                  {t.familyWhoDescription}
                </p>

                <div className="mt-4 grid gap-2 sm:grid-cols-2">

                  {familyOptions.map(
                    (item) => {
                      const selected =
                        familyMembers.includes(
                          item.id
                        );

                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() =>
                            toggleFamily(
                              item.id
                            )
                          }
                          className={`rounded-xl border p-4 text-left transition ${
                            selected
                              ? "border-orange-500 bg-orange-50"
                              : "border-white bg-white hover:border-orange-300"
                          }`}
                        >
                          <span className="mr-2">
                            {item.icon}
                          </span>

                          <span className="font-semibold">
                            {t[item.labelKey]}
                          </span>

                          {selected && (
                            <span className="float-right">
                              ✅
                            </span>
                          )}
                        </button>
                      );
                    }
                  )}

                </div>
              </div>
            )}

          {/* DOCUMENTS */}

          {(isNewcomer ||
            isResident) && (
            <div className="mt-8">

              <h3 className="font-bold">
                {t.documentsQuestion}
              </h3>

              <p className="mt-1 text-sm text-slate-500">
                {t.documentsDescription}
              </p>

              <div className="mt-4 space-y-3">

                {documentOptions.map(
                  (item) => {
                    const selected =
                      documents.includes(
                        item.id
                      );

                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() =>
                          toggleDocument(
                            item.id
                          )
                        }
                        className={`flex w-full items-center gap-4 rounded-2xl border p-4 text-left transition ${
                          selected
                            ? "border-green-500 bg-green-50"
                            : "border-slate-200 bg-white hover:border-orange-300"
                        }`}
                      >
                        <div className="text-3xl">
                          {item.icon}
                        </div>

                        <div className="flex-1">

                          <p className="font-bold">
                            {t[item.titleKey]}
                          </p>

                          <p className="text-sm text-slate-500">
                            {
                              t[
                                item.descriptionKey
                              ]
                            }
                          </p>

                        </div>

                        <div className="text-xl">
                          {selected
                            ? "✅"
                            : "○"}
                        </div>
                      </button>
                    );
                  }
                )}

              </div>
            </div>
          )}

          {/* LANGUAGE */}

          <div className="mt-8">

            <label className="font-bold">
              {t.preferredLanguage}
            </label>

            <p className="mt-1 text-sm text-slate-500">
              {t.languageDescription}
            </p>

            <div className="mt-3 flex flex-wrap gap-2">

              {supportedLanguages.map(
                (item) => (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() =>
                      handleLanguageChange(
                        item.code
                      )
                    }
                    className={`rounded-full px-4 py-2 font-semibold transition ${
                      language ===
                      item.code
                        ? "bg-blue-600 text-white"
                        : "border border-slate-200 bg-white hover:bg-blue-50"
                    }`}
                  >
                    {item.nativeName}
                  </button>
                )
              )}

            </div>
          </div>

          {/* SUMMARY */}

          <div className="mt-10 rounded-2xl bg-slate-50 p-5">

            <h3 className="font-bold">
              {t.profileSummary}
            </h3>

            <div className="mt-3 space-y-1 text-sm text-slate-600">

              {name && (
                <p>
                  👋 {t.nameLabel}:{" "}
                  {name}
                </p>
              )}

              {age && (
                <p>
                  🎂 {t.ageLabel}:{" "}
                  {age}
                </p>
              )}

              {profile && (
                <p>
                  👤 {t.profileLabel}:{" "}
                  {profile === "refugee"
                    ? t.refugeeTitle
                    : profile ===
                        "student"
                      ? t.studentTitle
                      : profile ===
                          "tourist"
                        ? t.touristTitle
                        : t.residentTitle}
                </p>
              )}

              {city && (
                <p>
                  📍{" "}
                  {isTourist
                    ? `${t.mainDestination}: ${city}`
                    : `${t.cityLabel}: ${city}`}
                </p>
              )}

              <p>
                🌐 {t.languageLabel}:{" "}
                {
                  supportedLanguages.find(
                    (item) =>
                      item.code ===
                      language
                  )?.nativeName
                }
              </p>

              {(isNewcomer ||
                isResident) &&
                hasFamily && (
                  <p>
                    👨‍👩‍👧‍👦{" "}
                    {t.familyLabel}:{" "}
                    {hasFamily === "yes"
                      ? t.familyYes
                      : t.familyNo}
                  </p>
                )}

              {(isNewcomer ||
                isResident) && (
                <p>
                  📄{" "}
                  {t.documentsSelected}:{" "}
                  {documents.length}
                </p>
              )}

            </div>
          </div>

          {/* SAVE */}

          <button
            type="button"
            onClick={handleContinue}
            disabled={!canContinue}
            className={`mt-8 w-full rounded-2xl py-4 font-bold transition ${
              canContinue
                ? "bg-orange-500 text-white hover:bg-orange-600"
                : "cursor-not-allowed bg-slate-200 text-slate-400"
            }`}
          >
            {canContinue
              ? t.saveProfile
              : t.completeProfile}
          </button>

          {/* PRIVACY */}

          <p className="mt-4 text-center text-xs text-slate-400">
            {t.privacyText}
          </p>

        </div>
      </section>
    </main>
  );
}