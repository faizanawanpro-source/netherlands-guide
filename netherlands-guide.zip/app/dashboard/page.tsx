"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type ProfileType =
  | "refugee"
  | "student"
  | "tourist"
  | "resident"
  | "dutch";

type Profile = {
  name?: string;
  age?: string;
  profile?: ProfileType | string;
  city?: string;
  language?: string;
  hasFamily?: string;
  familyMembers?: string[];
  documents?: string[];
};

type Tool = {
  href: string;
  icon: string;
  title: string;
  description: string;
  color: string;
};

const profileInfo: Record<
  ProfileType,
  {
    icon: string;
    label: string;
    subtitle: string;
    greeting: string;
  }
> = {
  refugee: {
    icon: "🕊️",
    label: "Refugee / newcomer",
    subtitle:
      "Your guide to settling into everyday life in the Netherlands.",
    greeting: "Let's make life in the Netherlands easier.",
  },

  student: {
    icon: "🎓",
    label: "International student",
    subtitle:
      "Your guide to studying, working and living in the Netherlands.",
    greeting: "Let's make student life easier.",
  },

  tourist: {
    icon: "✈️",
    label: "Tourist",
    subtitle:
      "Your personal travel guide to exploring the Netherlands.",
    greeting: "Let's make your Netherlands trip amazing.",
  },

  resident: {
    icon: "🏡",
    label: "Resident / immigrant",
    subtitle:
      "Your personal guide to everyday life in the Netherlands.",
    greeting: "Everything you need for life in the Netherlands.",
  },

  dutch: {
    icon: "🇳🇱",
    label: "Dutch citizen",
    subtitle:
      "Useful tools and information for everyday life in the Netherlands.",
    greeting: "Welcome to your Netherlands Guide.",
  },
};

const tools: Record<ProfileType, Tool[]> = {
  /* ============================================================
     REFUGEE / NEWCOMER
     Priority:
     Phone → Documents → Municipality → Healthcare → Money
     ============================================================ */

  refugee: [
    {
      href: "/dutch-phone-number",
      icon: "📱",
      title: "Dutch Phone Number",
      description:
        "Find out how to get a Dutch SIM card, phone number and mobile plan.",
      color: "from-orange-500 to-red-600",
    },
    {
      href: "/documents",
      icon: "📄",
      title: "Documents",
      description:
        "Understand BSN, DigiD, residence documents and official letters.",
      color: "from-blue-600 to-cyan-700",
    },
    {
      href: "/municipality",
      icon: "🏛️",
      title: "Municipality",
      description:
        "Understand registration, appointments and local government services.",
      color: "from-indigo-600 to-purple-700",
    },
    {
      href: "/healthcare",
      icon: "🏥",
      title: "Healthcare",
      description:
        "Learn about GPs, health insurance, medicines and healthcare.",
      color: "from-emerald-600 to-teal-700",
    },
    {
      href: "/money",
      icon: "💶",
      title: "Money & Banking",
      description:
        "Learn about bank accounts, payments, benefits and taxes.",
      color: "from-green-600 to-emerald-700",
    },
    {
      href: "/work",
      icon: "💼",
      title: "Work",
      description:
        "Understand jobs, contracts, salary and working rights.",
      color: "from-slate-700 to-slate-900",
    },
    {
      href: "/study",
      icon: "📚",
      title: "Dutch & Study",
      description:
        "Learn Dutch and discover education opportunities.",
      color: "from-violet-600 to-fuchsia-700",
    },
    {
      href: "/transport",
      icon: "🚆",
      title: "Transport",
      description:
        "Understand trains, buses, trams, metro and OVpay.",
      color: "from-blue-600 to-indigo-700",
    },
    {
      href: "/what-do-i-do",
      icon: "🚨",
      title: "What Do I Do?",
      description:
        "Get practical help when something unexpected happens.",
      color: "from-red-600 to-rose-700",
    },
    {
      href: "/waste",
      icon: "♻️",
      title: "Waste & Recycling",
      description:
        "Understand waste collection, recycling and local rules.",
      color: "from-lime-600 to-green-700",
    },
    {
      href: "/vehicles",
      icon: "🚗",
      title: "Vehicles",
      description:
        "Learn about driving, licences, cars, APK and vehicle rules.",
      color: "from-violet-600 to-purple-700",
    },
  ],

  /* ============================================================
     INTERNATIONAL STUDENT
     ============================================================ */

  student: [
    {
      href: "/study",
      icon: "🎓",
      title: "Study & Education",
      description:
        "Understand Dutch education, courses, schools and student life.",
      color: "from-indigo-600 to-purple-700",
    },
    {
      href: "/housing",
      icon: "🏠",
      title: "Student Housing",
      description:
        "Learn how to find accommodation and understand housing costs.",
      color: "from-orange-500 to-red-600",
    },
    {
      href: "/dutch-phone-number",
      icon: "📱",
      title: "Dutch Phone Number",
      description:
        "Find a Dutch SIM card, phone number and mobile plan.",
      color: "from-orange-500 to-amber-600",
    },
    {
      href: "/documents",
      icon: "📄",
      title: "Documents",
      description:
        "Understand important documents and Dutch administration.",
      color: "from-violet-600 to-purple-700",
    },
    {
      href: "/money",
      icon: "💶",
      title: "Money & Banking",
      description:
        "Understand banking, student finance, budgeting and payments.",
      color: "from-emerald-600 to-teal-700",
    },
    {
      href: "/work",
      icon: "💼",
      title: "Student Jobs",
      description:
        "Explore work opportunities and understand working in NL.",
      color: "from-slate-700 to-slate-900",
    },
    {
      href: "/transport",
      icon: "🚆",
      title: "Transport",
      description:
        "Learn how Dutch public transport works.",
      color: "from-blue-600 to-cyan-700",
    },
    {
      href: "/healthcare",
      icon: "🏥",
      title: "Healthcare",
      description:
        "Find practical information about healthcare and insurance.",
      color: "from-rose-600 to-red-700",
    },
    {
      href: "/what-do-i-do",
      icon: "🚨",
      title: "What Do I Do?",
      description:
        "Get practical help when something unexpected happens.",
      color: "from-red-600 to-rose-700",
    },
    {
      href: "/waste",
      icon: "♻️",
      title: "Waste & Recycling",
      description:
        "Understand waste collection and recycling in your municipality.",
      color: "from-lime-600 to-green-700",
    },
    {
      href: "/vehicles",
      icon: "🚗",
      title: "Vehicles",
      description:
        "Learn about driving, licences and vehicle information.",
      color: "from-violet-600 to-purple-700",
    },
    {
      href: "/explore",
      icon: "🗺️",
      title: "Explore",
      description:
        "Discover Dutch cities, places and activities.",
      color: "from-orange-500 to-amber-600",
    },
  ],

  /* ============================================================
     TOURIST
     ============================================================ */

  tourist: [
    {
      href: "/explore",
      icon: "🗺️",
      title: "Explore Netherlands",
      description:
        "Discover cities, attractions and places to visit.",
      color: "from-orange-500 to-red-600",
    },
    {
      href: "/trip-planner",
      icon: "🧳",
      title: "Trip Planner",
      description:
        "Build a personalised itinerary for your trip.",
      color: "from-indigo-600 to-purple-700",
    },
    {
      href: "/budget-planner",
      icon: "💶",
      title: "Trip Budget",
      description:
        "Estimate accommodation, transport, food and activities.",
      color: "from-emerald-600 to-teal-700",
    },
    {
      href: "/transport",
      icon: "🚆",
      title: "Transport",
      description:
        "Learn how to travel around the Netherlands.",
      color: "from-blue-600 to-cyan-700",
    },
    {
      href: "/chat",
      icon: "🤖",
      title: "Travel AI",
      description:
        "Ask anything about travelling in the Netherlands.",
      color: "from-violet-600 to-fuchsia-700",
    },
    {
      href: "/plan-day",
      icon: "📅",
      title: "Plan My Day",
      description:
        "Create a day plan based on your interests.",
      color: "from-rose-600 to-pink-700",
    },
    {
      href: "/what-do-i-do",
      icon: "🚨",
      title: "What Do I Do?",
      description:
        "Get practical help if something goes wrong.",
      color: "from-red-600 to-rose-700",
    },
    {
      href: "/explore",
      icon: "🍽️",
      title: "Food & Activities",
      description:
        "Find things to eat and things to do.",
      color: "from-amber-500 to-orange-600",
    },
  ],

  /* ============================================================
     RESIDENT / IMMIGRANT
     ============================================================ */

  resident: [
    {
      href: "/housing",
      icon: "🏠",
      title: "Housing",
      description:
        "Manage everyday housing information, renting and costs.",
      color: "from-orange-500 to-red-600",
    },
    {
      href: "/dutch-phone-number",
      icon: "📱",
      title: "Dutch Phone Number",
      description:
        "Get a Dutch phone number, SIM card or mobile plan.",
      color: "from-orange-500 to-amber-600",
    },
    {
      href: "/documents",
      icon: "📄",
      title: "Documents",
      description:
        "Understand important Dutch documents and administration.",
      color: "from-blue-600 to-cyan-700",
    },
    {
      href: "/municipality",
      icon: "🏛️",
      title: "Municipality",
      description:
        "Local government, registration and municipal services.",
      color: "from-indigo-600 to-purple-700",
    },
    {
      href: "/healthcare",
      icon: "🏥",
      title: "Healthcare",
      description:
        "Find useful healthcare, GP and insurance information.",
      color: "from-emerald-600 to-teal-700",
    },
    {
      href: "/money",
      icon: "💶",
      title: "Money & Banking",
      description:
        "Banking, payments, benefits, taxes and budgeting.",
      color: "from-green-600 to-emerald-700",
    },
    {
      href: "/work",
      icon: "💼",
      title: "Work",
      description:
        "Employment, contracts, salary and working information.",
      color: "from-slate-700 to-slate-900",
    },
    {
      href: "/transport",
      icon: "🚆",
      title: "Transport",
      description:
        "Public transport and getting around the Netherlands.",
      color: "from-blue-600 to-indigo-700",
    },
    {
      href: "/vehicles",
      icon: "🚗",
      title: "Vehicles",
      description:
        "Driving, cars, licences, APK and vehicle information.",
      color: "from-violet-600 to-purple-700",
    },
    {
      href: "/waste",
      icon: "♻️",
      title: "Waste & Recycling",
      description:
        "Understand waste collection and recycling in your municipality.",
      color: "from-lime-600 to-green-700",
    },
    {
      href: "/what-do-i-do",
      icon: "🚨",
      title: "What Do I Do?",
      description:
        "Get practical help when something unexpected happens.",
      color: "from-red-600 to-rose-700",
    },
    {
      href: "/explore",
      icon: "🗺️",
      title: "Explore",
      description:
        "Discover cities, places and activities around the Netherlands.",
      color: "from-orange-500 to-amber-600",
    },
  ],

  /* ============================================================
     DUTCH CITIZEN
     ============================================================ */

  dutch: [
    {
      href: "/municipality",
      icon: "🏛️",
      title: "Municipality",
      description:
        "Find municipal services, information and contacts.",
      color: "from-indigo-600 to-purple-700",
    },
    {
      href: "/healthcare",
      icon: "🏥",
      title: "Healthcare",
      description:
        "Healthcare, insurance, GPs and useful services.",
      color: "from-emerald-600 to-teal-700",
    },
    {
      href: "/money",
      icon: "💶",
      title: "Money",
      description:
        "Banking, payments, taxes and financial information.",
      color: "from-green-600 to-emerald-700",
    },
    {
      href: "/work",
      icon: "💼",
      title: "Work",
      description:
        "Employment information and working rights.",
      color: "from-slate-700 to-slate-900",
    },
    {
      href: "/transport",
      icon: "🚆",
      title: "Transport",
      description:
        "Public transport and getting around NL.",
      color: "from-blue-600 to-cyan-700",
    },
    {
      href: "/vehicles",
      icon: "🚗",
      title: "Vehicles",
      description:
        "Driving, cars, APK and vehicle information.",
      color: "from-violet-600 to-purple-700",
    },
    {
      href: "/waste",
      icon: "♻️",
      title: "Waste & Recycling",
      description:
        "Waste collection and recycling information.",
      color: "from-lime-600 to-green-700",
    },
    {
      href: "/what-do-i-do",
      icon: "🚨",
      title: "What Do I Do?",
      description:
        "Get practical help when something unexpected happens.",
      color: "from-red-600 to-rose-700",
    },
    {
      href: "/explore",
      icon: "🗺️",
      title: "Explore",
      description:
        "Discover cities, places and activities.",
      color: "from-orange-500 to-amber-600",
    },
  ],
};

const familyLabels: Record<string, string> = {
  partner: "Partner",
  children: "Children",
  parents: "Parents",
  siblings: "Brothers / sisters",
  other: "Other family",
};

const documentLabels: Record<string, string> = {
  bsn: "BSN",
  digid: "DigiD",
  residence: "Residence document",
  municipality: "Municipality registration",
  letters: "Official letters",
};

export default function DashboardPage() {
  const [profile, setProfile] = useState<Profile>({});
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);

    try {
      const savedProfile = localStorage.getItem(
        "netherlandsGuideProfile"
      );

      if (savedProfile) {
        const parsedProfile: Profile = JSON.parse(savedProfile);
        setProfile(parsedProfile);
      }
    } catch (error) {
      console.error("Could not load profile:", error);
    }
  }, []);

  const currentProfile: ProfileType =
    profile.profile === "student" ||
    profile.profile === "tourist" ||
    profile.profile === "resident" ||
    profile.profile === "refugee" ||
    profile.profile === "dutch"
      ? profile.profile
      : "refugee";

  const info = profileInfo[currentProfile];

  const personalizedTools = useMemo(() => {
    return tools[currentProfile];
  }, [currentProfile]);

  if (!mounted) {
    return null;
  }

  const displayName = profile.name?.trim() || "there";

  const familyList =
    profile.familyMembers?.map(
      (member) => familyLabels[member] || member
    ) || [];

  const documentList =
    profile.documents?.map(
      (document) => documentLabels[document] || document
    ) || [];

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">

      {/* NAVIGATION */}
      <nav className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 sm:px-6">

          <Link
            href="/dashboard"
            className="flex items-center gap-3 transition hover:opacity-80"
          >
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-50 text-2xl">
              🇳🇱
            </div>

            <div>
              <p className="font-black">
                Netherlands Guide
              </p>

              <p className="hidden text-xs text-slate-500 sm:block">
                Your personalised Netherlands assistant
              </p>
            </div>
          </Link>

          <Link
            href="/onboarding"
            className="rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-bold transition hover:border-orange-300 hover:bg-orange-50"
          >
            Edit profile
          </Link>

        </div>
      </nav>


      <div className="mx-auto max-w-7xl px-5 py-8 sm:px-6 sm:py-10">

        {/* HERO */}
        <section className="overflow-hidden rounded-[2rem] bg-gradient-to-br from-orange-500 via-orange-500 to-red-600 p-7 text-white shadow-xl sm:p-10">

          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">

            <div>

              <div className="flex flex-wrap items-center gap-2">

                <span className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold backdrop-blur">
                  {info.icon} {info.label}
                </span>

                {profile.city && (
                  <span className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold backdrop-blur">
                    📍 {profile.city}
                  </span>
                )}

              </div>

              <h1 className="mt-5 text-3xl font-black sm:text-5xl">
                Hi {displayName}! 👋
              </h1>

              <p className="mt-4 max-w-2xl text-lg leading-8 text-orange-50">
                {info.greeting}
              </p>

              <p className="mt-2 max-w-2xl text-sm text-orange-100">
                {info.subtitle}
              </p>

              <div className="mt-6 flex flex-wrap gap-2">

                {profile.age && (
                  <span className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold backdrop-blur">
                    🎂 {profile.age}
                  </span>
                )}

                {profile.language && (
                  <span className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold backdrop-blur">
                    🌐 {profile.language}
                  </span>
                )}

                {profile.hasFamily && (
                  <span className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold backdrop-blur">
                    👨‍👩‍👧‍👦{" "}
                    {profile.hasFamily === "yes"
                      ? "Family in NL"
                      : "No family in NL"}
                  </span>
                )}

              </div>
            </div>

            <div className="hidden rounded-3xl bg-white/10 p-7 backdrop-blur lg:block">

              <p className="text-sm font-bold text-orange-100">
                Your guide
              </p>

              <p className="mt-2 text-4xl font-black">
                Personalised
              </p>

              <p className="mt-2 max-w-xs text-sm text-orange-100">
                Your dashboard changes based on the information you gave us.
              </p>

            </div>

          </div>

        </section>


        {/* TOOLS */}
        <section className="mt-10">

          <div className="mb-6">

            <p className="text-sm font-black uppercase tracking-[0.18em] text-orange-500">
              Recommended for you
            </p>

            <h2 className="mt-2 text-3xl font-black">
              Your most useful tools
            </h2>

            <p className="mt-2 max-w-2xl text-slate-500">
              These tools are selected based on your profile.
            </p>

          </div>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">

            {personalizedTools.map((tool) => (

              <Link
                key={`${tool.href}-${tool.title}`}
                href={tool.href}
                className={`group overflow-hidden rounded-[2rem] bg-gradient-to-br ${tool.color} p-6 text-white shadow-lg transition duration-200 hover:-translate-y-1 hover:shadow-2xl`}
              >

                <div className="flex items-center justify-between">

                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15 text-3xl">
                    {tool.icon}
                  </div>

                  <span className="text-2xl text-white/60 transition group-hover:translate-x-1">
                    →
                  </span>

                </div>

                <h3 className="mt-5 text-xl font-black">
                  {tool.title}
                </h3>

                <p className="mt-2 text-sm leading-6 text-white/80">
                  {tool.description}
                </p>

              </Link>

            ))}

          </div>

        </section>


        {/* SMART AI TOOLS */}
        <section className="mt-12">

          <div className="mb-6">

            <p className="text-sm font-black uppercase tracking-[0.18em] text-indigo-600">
              🤖 Smart tools
            </p>

            <h2 className="mt-2 text-3xl font-black">
              Get help instantly
            </h2>

            <p className="mt-2 max-w-2xl text-slate-500">
              Use AI and practical tools when you need help.
            </p>

          </div>

          <div className="grid gap-5 md:grid-cols-3">

            <Link
              href="/chat"
              className="group overflow-hidden rounded-[2rem] bg-gradient-to-br from-slate-900 via-indigo-950 to-purple-950 p-7 text-white shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div className="text-4xl">
                🤖
              </div>

              <h3 className="mt-6 text-2xl font-black">
                Ask AI
              </h3>

              <p className="mt-3 text-sm leading-6 text-slate-300">
                Ask questions about the Netherlands and get explanations
                based on your situation.
              </p>

              <div className="mt-6 rounded-xl bg-white/10 px-4 py-3 text-sm font-bold">
                🤖 Ask Netherlands Guide →
              </div>
            </Link>


            <Link
              href="/scanner"
              className="group overflow-hidden rounded-[2rem] bg-gradient-to-br from-emerald-600 to-teal-700 p-7 text-white shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div className="text-4xl">
                📄
              </div>

              <h3 className="mt-6 text-2xl font-black">
                Scan a Letter
              </h3>

              <p className="mt-3 text-sm leading-6 text-white/80">
                Take a photo of a Dutch letter and get help understanding
                what it says.
              </p>

              <div className="mt-6 rounded-xl bg-white/10 px-4 py-3 text-sm font-bold">
                📷 Open document scanner →
              </div>
            </Link>


            <Link
              href="/voice"
              className="group overflow-hidden rounded-[2rem] bg-gradient-to-br from-indigo-600 to-purple-700 p-7 text-white shadow-lg transition hover:-translate-y-1 hover:shadow-2xl"
            >
              <div className="text-4xl">
                🎤
              </div>

              <h3 className="mt-6 text-2xl font-black">
                Voice Assistant
              </h3>

              <p className="mt-3 text-sm leading-6 text-white/80">
                Speak naturally and get help using your voice.
              </p>

              <div className="mt-6 rounded-xl bg-white/10 px-4 py-3 text-sm font-bold">
                🎤 Talk to Netherlands Guide →
              </div>
            </Link>

          </div>

        </section>


        {/* PROFILE */}
        <section className="mt-12">

          <div className="rounded-[2rem] border border-slate-200 bg-white p-7 shadow-sm sm:p-8">

            <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">

              <div>

                <p className="text-sm font-black uppercase tracking-[0.18em] text-slate-400">
                  Your profile
                </p>

                <h2 className="mt-2 text-2xl font-black">
                  {info.icon} {info.label}
                </h2>

                <p className="mt-2 text-sm text-slate-500">
                  Your guide uses these details to personalise your experience.
                </p>

              </div>

              <Link
                href="/onboarding"
                className="rounded-xl border border-slate-200 px-5 py-3 text-center text-sm font-bold transition hover:border-orange-300 hover:bg-orange-50"
              >
                Edit my profile
              </Link>

            </div>


            <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">

              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-bold uppercase text-slate-400">
                  Name
                </p>

                <p className="mt-1 font-bold">
                  {profile.name || "Not set"}
                </p>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-bold uppercase text-slate-400">
                  Profile
                </p>

                <p className="mt-1 font-bold">
                  {info.label}
                </p>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-bold uppercase text-slate-400">
                  Location
                </p>

                <p className="mt-1 font-bold">
                  {profile.city || "Not set"}
                </p>
              </div>

              <div className="rounded-2xl bg-slate-50 p-4">
                <p className="text-xs font-bold uppercase text-slate-400">
                  Language
                </p>

                <p className="mt-1 font-bold">
                  {profile.language || "English"}
                </p>
              </div>

            </div>


            {/* FAMILY */}

            {(currentProfile === "refugee" ||
              currentProfile === "resident") &&
              profile.hasFamily && (

                <div className="mt-4 rounded-2xl bg-slate-50 p-5">

                  <p className="text-xs font-bold uppercase text-slate-400">
                    Family
                  </p>

                  <p className="mt-2 font-bold">
                    {profile.hasFamily === "yes"
                      ? "Family in the Netherlands"
                      : "No family in the Netherlands"}
                  </p>

                  {familyList.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">

                      {familyList.map((family) => (
                        <span
                          key={family}
                          className="rounded-full bg-white px-3 py-1 text-sm font-semibold text-slate-600"
                        >
                          👨‍👩‍👧‍👦 {family}
                        </span>
                      ))}

                    </div>
                  )}

                </div>

              )}


            {/* DOCUMENTS */}

            {(currentProfile === "refugee" ||
              currentProfile === "resident") && (

                <div className="mt-4 rounded-2xl bg-slate-50 p-5">

                  <div className="flex items-center justify-between">

                    <div>

                      <p className="text-xs font-bold uppercase text-slate-400">
                        Documents & services
                      </p>

                      <p className="mt-1 font-bold">
                        {documentList.length > 0
                          ? `${documentList.length} selected`
                          : "None selected"}
                      </p>

                    </div>

                    <span className="text-2xl">
                      📄
                    </span>

                  </div>

                  {documentList.length > 0 && (

                    <div className="mt-3 flex flex-wrap gap-2">

                      {documentList.map((document) => (

                        <span
                          key={document}
                          className="rounded-full bg-white px-3 py-1 text-sm font-semibold text-slate-600"
                        >
                          📄 {document}
                        </span>

                      ))}

                    </div>

                  )}

                </div>

              )}

          </div>

        </section>


        {/* TOURIST EXTRA */}

        {currentProfile === "tourist" && (

          <section className="mt-10">

            <div className="rounded-[2rem] border border-orange-200 bg-orange-50 p-7">

              <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">

                <div>

                  <p className="text-sm font-black uppercase tracking-widest text-orange-600">
                    ✈️ Tourist mode
                  </p>

                  <h2 className="mt-2 text-2xl font-black text-orange-950">
                    Ready to explore?
                  </h2>

                  <p className="mt-2 max-w-2xl text-sm leading-6 text-orange-800">

                    {profile.city
                      ? `Your selected destination is ${profile.city}.`
                      : "You haven't selected a main destination yet."}

                    {" "}Use the trip planner to build your itinerary.

                  </p>

                </div>

                <Link
                  href="/trip-planner"
                  className="rounded-xl bg-orange-500 px-6 py-3 text-center font-black text-white transition hover:bg-orange-600"
                >
                  Plan my trip →
                </Link>

              </div>

            </div>

          </section>

        )}


        {/* EMERGENCY */}

        <section className="mt-10">

          <div className="rounded-[2rem] border-2 border-red-200 bg-red-50 p-6 sm:p-7">

            <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">

              <div>

                <div className="flex items-center gap-3">

                  <span className="text-3xl">
                    🚨
                  </span>

                  <h2 className="text-xl font-black text-red-900">
                    Emergency?
                  </h2>

                </div>

                <p className="mt-2 max-w-2xl text-sm leading-6 text-red-800">
                  If someone is in immediate danger or there is a serious
                  emergency, call 112.
                </p>

              </div>

              <a
                href="tel:112"
                className="rounded-xl bg-red-600 px-6 py-3 text-center font-black text-white shadow-sm transition hover:bg-red-700"
              >
                🚨 Call 112
              </a>

            </div>

          </div>

        </section>


        {/* FOOTER */}

        <footer className="py-10 text-center text-sm text-slate-400">

          Netherlands Guide 🇳🇱

          <span className="mx-2">
            ·
          </span>

          Your personalised guide to the Netherlands

        </footer>

      </div>

    </main>
  );
}