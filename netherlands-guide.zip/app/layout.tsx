import type { Metadata } from "next";
import "./globals.css";
import VoiceAssistant from "@/components/VoiceAssistant";
import { LanguageProvider } from "@/components/LanguageProvider";

export const metadata: Metadata = {
  title: "Netherlands Guide",
  description:
    "Your personal guide to life in the Netherlands",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <LanguageProvider>
          {children}
        </LanguageProvider>

        <VoiceAssistant />
      </body>
    </html>
  );
}