export type SupportedLanguage =
  | "English"
  | "Nederlands"
  | "اردو"
  | "हिन्दी"
  | "ਪੰਜਾਬੀ"
  | "العربية"
  | "Türkçe"
  | "Українська";

export type TranslationKeys = {
  // General
  appName: string;
  appDescription: string;
  home: string;
  dashboard: string;
  settings: string;
  back: string;
  next: string;
  save: string;
  cancel: string;
  search: string;
  loading: string;
  continue: string;
  close: string;

  // Dashboard
  dashboardTitle: string;
  dashboardDescription: string;
  welcomeBack: string;
  whatCanWeHelp: string;

  // Categories
  transport: string;
  housing: string;
  jobs: string;
  healthcare: string;
  government: string;
  education: string;
  money: string;
  dailyLife: string;
  emergency: string;
  travel: string;

  // Transport
  publicTransport: string;
  trains: string;
  buses: string;
  metro: string;
  tram: string;
  ovChipkaart: string;

  // Housing
  findHousing: string;
  renting: string;
  socialHousing: string;
  housingBenefits: string;

  // Jobs
  findJob: string;
  jobSearch: string;
  employment: string;
  salary: string;

  // Healthcare
  doctor: string;
  pharmacy: string;
  healthInsurance: string;
  huisarts: string;

  // Government
  municipality: string;
  digid: string;
  bsn: string;
  ind: string;
  officialLetters: string;

  // Education
  schools: string;
  university: string;
  studentFinance: string;
  dutchCourses: string;

  // Money
  bankAccount: string;
  taxes: string;
  benefits: string;

  // Profile
  profile: string;
  editProfile: string;
  language: string;
  city: string;
  age: string;
  family: string;
  documents: string;

  // Onboarding
  personalizeGuide: string;
  setupProfile: string;
  profileDescription: string;

  nameQuestion: string;
  namePlaceholder: string;

  ageQuestion: string;
  agePlaceholder: string;

  profileQuestion: string;

  refugeeTitle: string;
  refugeeDescription: string;

  studentTitle: string;
  studentDescription: string;

  touristTitle: string;
  touristDescription: string;

  residentTitle: string;
  residentDescription: string;

  cityQuestion: string;
  cityStudyQuestion: string;
  cityDescription: string;
  chooseCity: string;

  familyQuestion: string;
  familyYes: string;
  familyYesDescription: string;
  familyNo: string;
  familyNoDescription: string;

  familyWho: string;
  familyWhoDescription: string;

  partner: string;
  children: string;
  parents: string;
  siblings: string;
  otherFamily: string;

  documentsQuestion: string;
  documentsDescription: string;

  bsnTitle: string;
  bsnDescription: string;

  digidTitle: string;
  digidDescription: string;

  residenceTitle: string;
  residenceDescription: string;

  municipalityTitle: string;
  municipalityDescription: string;

  officialLettersTitle: string;
  officialLettersDescription: string;

  preferredLanguage: string;
  languageDescription: string;

  profileSummary: string;
  saveProfile: string;
  completeProfile: string;

  privacyText: string;
  loadingProfile: string;

  nameLabel: string;
  ageLabel: string;
  profileLabel: string;
  cityLabel: string;
  languageLabel: string;
  familyLabel: string;
  documentsSelected: string;
};

const english: TranslationKeys = {
  appName: "Netherlands Guide",
  appDescription: "Your guide to life and travel in the Netherlands",

  home: "Home",
  dashboard: "Dashboard",
  settings: "Settings",
  back: "Back",
  next: "Next",
  save: "Save",
  cancel: "Cancel",
  search: "Search",
  loading: "Loading...",
  continue: "Continue",
  close: "Close",

  dashboardTitle: "Your Netherlands Guide",
  dashboardDescription:
    "Everything you need for life, work, study and travel in the Netherlands.",
  welcomeBack: "Welcome back",
  whatCanWeHelp: "What can we help you with?",

  transport: "Transport",
  housing: "Housing",
  jobs: "Jobs",
  healthcare: "Healthcare",
  government: "Government",
  education: "Education",
  money: "Money & finances",
  dailyLife: "Daily life",
  emergency: "Emergency",
  travel: "Travel",

  publicTransport: "Public transport",
  trains: "Trains",
  buses: "Buses",
  metro: "Metro",
  tram: "Tram",
  ovChipkaart: "OV-chipkaart",

  findHousing: "Find housing",
  renting: "Renting",
  socialHousing: "Social housing",
  housingBenefits: "Housing benefits",

  findJob: "Find a job",
  jobSearch: "Job search",
  employment: "Employment",
  salary: "Salary",

  doctor: "Doctor",
  pharmacy: "Pharmacy",
  healthInsurance: "Health insurance",
  huisarts: "Huisarts",

  municipality: "Municipality",
  digid: "DigiD",
  bsn: "BSN",
  ind: "IND",
  officialLetters: "Official letters",

  schools: "Schools",
  university: "University",
  studentFinance: "Student finance",
  dutchCourses: "Dutch courses",

  bankAccount: "Bank account",
  taxes: "Taxes",
  benefits: "Benefits",

  profile: "Profile",
  editProfile: "Edit profile",
  language: "Language",
  city: "City",
  age: "Age",
  family: "Family",
  documents: "Documents",

  personalizeGuide: "Personalize your guide",
  setupProfile: "Let's set up your profile",
  profileDescription:
    "Tell us a little about yourself so we can show you the information and tools that actually matter to you.",

  nameQuestion: "What is your name?",
  namePlaceholder: "e.g. Faizan",

  ageQuestion: "How old are you?",
  agePlaceholder: "e.g. 25",

  profileQuestion: "Which describes you best?",

  refugeeTitle: "Refugee / newcomer",
  refugeeDescription:
    "I am settling into life in the Netherlands.",

  studentTitle: "International student",
  studentDescription:
    "I am studying or starting my education.",

  touristTitle: "Tourist",
  touristDescription:
    "I am visiting the Netherlands.",

  residentTitle: "Resident",
  residentDescription:
    "I already live in the Netherlands.",

  cityQuestion: "Which city do you live in?",
  cityStudyQuestion: "Which city do you live or study in?",
  cityDescription: "Choose the city that is most relevant to you.",
  chooseCity: "Choose your city",

  familyQuestion: "Do you have family in the Netherlands?",
  familyYes: "Yes",
  familyYesDescription: "I have family here.",
  familyNo: "No",
  familyNoDescription: "I don't have family here.",

  familyWho: "Who do you have here?",
  familyWhoDescription: "You can choose more than one.",

  partner: "Partner / wife / husband",
  children: "Children",
  parents: "Parents",
  siblings: "Brothers / sisters",
  otherFamily: "Other family",

  documentsQuestion:
    "Which documents or services do you already have?",
  documentsDescription:
    "This helps us personalize your Netherlands-life tools.",

  bsnTitle: "BSN",
  bsnDescription: "My citizen service number",

  digidTitle: "DigiD",
  digidDescription: "My Dutch digital identity",

  residenceTitle: "Residence document",
  residenceDescription:
    "My residence permit or document",

  municipalityTitle:
    "Municipality registration (Gemeente)",
  municipalityDescription:
    "I am registered with a Dutch municipality (Gemeente)",

  officialLettersTitle: "Official letters",
  officialLettersDescription:
    "I receive letters from Dutch authorities",

  preferredLanguage: "Preferred language",
  languageDescription:
    "We'll use this for your guide and explanations.",

  profileSummary: "Your profile",
  saveProfile: "Save my profile →",
  completeProfile: "Complete your profile to continue",

  privacyText:
    "Your profile is currently stored only on this device. Never enter your DigiD password, PIN or other secret login details.",

  loadingProfile: "Loading your profile...",

  nameLabel: "Name",
  ageLabel: "Age",
  profileLabel: "Profile",
  cityLabel: "City",
  languageLabel: "Language",
  familyLabel: "Family in Netherlands",
  documentsSelected: "Documents selected",
};