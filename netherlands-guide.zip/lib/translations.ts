export const SUPPORTED_LANGUAGES = [
  "en",
  "nl",
  "ar",
  "ur",
  "hi",
  "pa",
  "tr",
] as const;

export type SupportedLanguage =
  (typeof SUPPORTED_LANGUAGES)[number];

export type TranslationKeys = {
  loadingProfile: string;
  appName: string;
  appDescription: string;

  editProfile: string;
  getStarted: string;

  personalizeGuide: string;
  welcomeBack: string;
  setupProfile: string;
  profileDescription: string;

  nameQuestion: string;
  namePlaceholder: string;

  ageQuestion: string;
  agePlaceholder: string;

  profileQuestion: string;

  refugeeTitle: string;
  refugeeDescription: string;

  studentTitle: string;
  studentDescription: string;

  touristTitle: string;
  touristDescription: string;

  residentTitle: string;
  residentDescription: string;

  welcomeTraveller: string;
  travellerDescription: string;

  cityStudyQuestion: string;
  cityQuestion: string;
  cityDescription: string;
  chooseCity: string;

  touristDestination: string;
  touristDestinationDescription: string;
  optional: string;
  notDecided: string;

  familyQuestion: string;
  familyYes: string;
  familyYesDescription: string;
  familyNo: string;
  familyNoDescription: string;

  familyWho: string;
  familyWhoDescription: string;

  partner: string;
  children: string;
  parents: string;
  siblings: string;
  otherFamily: string;

  documentsQuestion: string;
  documentsDescription: string;

  bsnTitle: string;
  bsnDescription: string;

  digidTitle: string;
  digidDescription: string;

  residenceTitle: string;
  residenceDescription: string;

  municipalityTitle: string;
  municipalityDescription: string;

  officialLettersTitle: string;
  officialLettersDescription: string;

  preferredLanguage: string;
  languageDescription: string;

  profileSummary: string;
  nameLabel: string;
  ageLabel: string;
  profileLabel: string;
  cityLabel: string;
  languageLabel: string;
  familyLabel: string;
  documentsSelected: string;

  saveProfile: string;
  completeProfile: string;
  privacyText: string;

  mainDestination: string;
};

const english: TranslationKeys = {
  loadingProfile: "Loading your profile...",

  appName: "Netherlands Guide",
  appDescription: "Your personalised Netherlands assistant",

  editProfile: "Edit profile",
  getStarted: "Get started",

  personalizeGuide: "Personalise your guide",
  welcomeBack: "Welcome back",
  setupProfile: "Set up your profile",
  profileDescription:
    "Tell us a little about yourself so we can personalise your Netherlands Guide.",

  nameQuestion: "What is your name?",
  namePlaceholder: "Enter your name",

  ageQuestion: "How old are you?",
  agePlaceholder: "Enter your age",

  profileQuestion: "Which best describes you?",

  refugeeTitle: "Refugee / newcomer",
  refugeeDescription:
    "Help with settling into everyday life in the Netherlands.",

  studentTitle: "International student",
  studentDescription:
    "Help with studying, working and living in the Netherlands.",

  touristTitle: "Tourist",
  touristDescription:
    "Travel information and help exploring the Netherlands.",

  residentTitle: "Resident",
  residentDescription:
    "Practical information for everyday life in the Netherlands.",

  welcomeTraveller: "Welcome, traveller!",
  travellerDescription:
    "Tell us where you are visiting and we will personalise your travel experience.",

  cityStudyQuestion: "Which city do you study in?",
  cityQuestion: "Which city do you live in?",
  cityDescription:
    "Choose your city so we can show you information relevant to your area.",
  chooseCity: "Choose a city",

  touristDestination: "Where are you travelling?",
  touristDestinationDescription:
    "Choose your main destination if you already know it.",
  optional: "Optional",
  notDecided: "I haven't decided yet",

  familyQuestion:
    "Do you have family in the Netherlands?",
  familyYes: "Yes, I have family",
  familyYesDescription:
    "Tell us which family members are here.",
  familyNo: "No, I don't have family",
  familyNoDescription:
    "Continue without adding family information.",

  familyWho: "Who is here?",
  familyWhoDescription:
    "Select the family members who are in the Netherlands.",

  partner: "Partner",
  children: "Children",
  parents: "Parents",
  siblings: "Brothers / sisters",
  otherFamily: "Other family",

  documentsQuestion:
    "Which documents or services do you have?",
  documentsDescription:
    "Select the documents or services that are relevant to you.",

  bsnTitle: "BSN",
  bsnDescription:
    "Your Dutch citizen service number.",

  digidTitle: "DigiD",
  digidDescription:
    "Your digital identity for Dutch government services.",

  residenceTitle: "Residence document",
  residenceDescription:
    "Your Dutch residence permit or residence document.",

  municipalityTitle: "Municipality registration",
  municipalityDescription:
    "Registration with your Dutch municipality.",

  officialLettersTitle: "Official letters",
  officialLettersDescription:
    "Letters and documents from Dutch organisations or government services.",

  preferredLanguage: "Preferred language",
  languageDescription:
    "Choose the language you would like to use in the app.",

  profileSummary: "Your profile",
  nameLabel: "Name",
  ageLabel: "Age",
  profileLabel: "Profile",
  cityLabel: "City",
  languageLabel: "Language",
  familyLabel: "Family",
  documentsSelected: "Documents selected",

  saveProfile: "Continue to my guide →",
  completeProfile: "Complete your profile",

  privacyText:
    "Your information is stored locally on your device and is used to personalise your experience.",

  mainDestination: "Main destination",
};

/*
 * We keep the English object as the complete type-safe base.
 * Other languages can override individual strings.
 *
 * This means the application will NEVER crash or show
 * "property does not exist" because of a missing translation.
 */

const translations: Record<
  SupportedLanguage,
  Partial<TranslationKeys>
> = {
  en: {},

  nl: {
    loadingProfile: "Je profiel wordt geladen...",
    appName: "Netherlands Guide",
    appDescription: "Jouw persoonlijke assistent voor Nederland",
    editProfile: "Profiel bewerken",
    getStarted: "Aan de slag",

    personalizeGuide: "Personaliseer je gids",
    welcomeBack: "Welkom terug",
    setupProfile: "Stel je profiel in",
    profileDescription:
      "Vertel ons iets over jezelf zodat we je gids kunnen personaliseren.",

    nameQuestion: "Wat is je naam?",
    namePlaceholder: "Vul je naam in",

    ageQuestion: "Hoe oud ben je?",
    agePlaceholder: "Vul je leeftijd in",

    profileQuestion: "Welke situatie past het beste bij jou?",

    refugeeTitle: "Vluchteling / nieuwkomer",
    refugeeDescription:
      "Hulp bij het dagelijks leven in Nederland.",

    studentTitle: "Internationale student",
    studentDescription:
      "Hulp bij studeren, werken en wonen in Nederland.",

    touristTitle: "Toerist",
    touristDescription:
      "Reisinformatie en hulp bij het ontdekken van Nederland.",

    residentTitle: "Inwoner",
    residentDescription:
      "Praktische informatie voor het dagelijks leven in Nederland.",

    welcomeTraveller: "Welkom, reiziger!",
    travellerDescription:
      "Vertel ons waar je naartoe gaat zodat we je reis kunnen personaliseren.",

    cityStudyQuestion: "In welke stad studeer je?",
    cityQuestion: "In welke stad woon je?",
    cityDescription:
      "Kies je stad zodat we informatie voor jouw omgeving kunnen tonen.",
    chooseCity: "Kies een stad",

    touristDestination: "Waar ga je naartoe?",
    touristDestinationDescription:
      "Kies je belangrijkste bestemming als je die al weet.",
    optional: "Optioneel",
    notDecided: "Ik weet het nog niet",

    familyQuestion:
      "Heb je familie in Nederland?",
    familyYes: "Ja, ik heb familie",
    familyNo: "Nee, ik heb geen familie",

    familyWho: "Wie is hier?",
    familyWhoDescription:
      "Selecteer de familieleden die in Nederland zijn.",

    partner: "Partner",
    children: "Kinderen",
    parents: "Ouders",
    siblings: "Broers / zussen",
    otherFamily: "Andere familie",

    documentsQuestion:
      "Welke documenten of diensten heb je?",
    documentsDescription:
      "Selecteer de documenten of diensten die voor jou relevant zijn.",

    preferredLanguage: "Voorkeurstaal",
    languageDescription:
      "Kies de taal die je in de app wilt gebruiken.",

    profileSummary: "Je profiel",
    nameLabel: "Naam",
    ageLabel: "Leeftijd",
    profileLabel: "Profiel",
    cityLabel: "Stad",
    languageLabel: "Taal",
    familyLabel: "Familie",
    documentsSelected: "Geselecteerde documenten",

    saveProfile: "Naar mijn gids →",
    completeProfile: "Voltooi je profiel",

    privacyText:
      "Je gegevens worden lokaal op je apparaat opgeslagen.",
    mainDestination: "Hoofdbestemming",
  },

  ur: {
    appDescription: "نیدرلینڈز کے لیے آپ کا ذاتی اسسٹنٹ",
    editProfile: "پروفائل تبدیل کریں",
    getStarted: "شروع کریں",
    personalizeGuide: "اپنی گائیڈ کو ذاتی بنائیں",
    welcomeBack: "خوش آمدید",
    setupProfile: "اپنا پروفائل بنائیں",
    profileDescription:
      "اپنے بارے میں کچھ معلومات دیں تاکہ ہم آپ کی گائیڈ کو ذاتی بنا سکیں۔",
    nameQuestion: "آپ کا نام کیا ہے؟",
    namePlaceholder: "اپنا نام درج کریں",
    ageQuestion: "آپ کی عمر کتنی ہے؟",
    agePlaceholder: "اپنی عمر درج کریں",
    profileQuestion: "آپ کو کون سا آپشن بیان کرتا ہے؟",
    refugeeTitle: "پناہ گزین / نیا آنے والا",
    studentTitle: "بین الاقوامی طالب علم",
    touristTitle: "سیاح",
    residentTitle: "رہائشی",
    cityQuestion: "آپ کس شہر میں رہتے ہیں؟",
    cityStudyQuestion: "آپ کس شہر میں پڑھتے ہیں؟",
    chooseCity: "شہر منتخب کریں",
    touristDestination: "آپ کہاں جا رہے ہیں؟",
    optional: "اختیاری",
    notDecided: "ابھی فیصلہ نہیں کیا",
    familyQuestion: "کیا نیدرلینڈز میں آپ کا خاندان ہے؟",
    familyYes: "ہاں، میرا خاندان ہے",
    familyNo: "نہیں، میرا خاندان نہیں ہے",
    familyWho: "کون یہاں موجود ہے؟",
    preferredLanguage: "پسندیدہ زبان",
    profileSummary: "آپ کا پروفائل",
    nameLabel: "نام",
    ageLabel: "عمر",
    profileLabel: "پروفائل",
    cityLabel: "شہر",
    languageLabel: "زبان",
    familyLabel: "خاندان",
    documentsSelected: "منتخب دستاویزات",
    saveProfile: "میری گائیڈ پر جائیں →",
    completeProfile: "اپنا پروفائل مکمل کریں",
    mainDestination: "اہم منزل",
  },

  ar: {
    appDescription: "مساعدك الشخصي في هولندا",
    editProfile: "تعديل الملف الشخصي",
    getStarted: "ابدأ",
    personalizeGuide: "خصص دليلك",
    welcomeBack: "مرحباً بعودتك",
    setupProfile: "أنشئ ملفك الشخصي",
    profileQuestion: "ما الخيار الذي يصفك بشكل أفضل؟",
    refugeeTitle: "لاجئ / وافد جديد",
    studentTitle: "طالب دولي",
    touristTitle: "سائح",
    residentTitle: "مقيم",
    nameQuestion: "ما اسمك؟",
    ageQuestion: "كم عمرك؟",
    cityQuestion: "في أي مدينة تعيش؟",
    cityStudyQuestion: "في أي مدينة تدرس؟",
    chooseCity: "اختر مدينة",
    touristDestination: "إلى أين تسافر؟",
    optional: "اختياري",
    notDecided: "لم أقرر بعد",
    familyQuestion: "هل لديك عائلة في هولندا؟",
    familyYes: "نعم، لدي عائلة",
    familyNo: "لا، ليس لدي عائلة",
    preferredLanguage: "اللغة المفضلة",
    profileSummary: "ملفك الشخصي",
    saveProfile: "انتقل إلى دليلي →",
    completeProfile: "أكمل ملفك الشخصي",
    mainDestination: "الوجهة الرئيسية",
  },

  hi: {
    appDescription: "नीदरलैंड्स के लिए आपका व्यक्तिगत सहायक",
    editProfile: "प्रोफ़ाइल संपादित करें",
    getStarted: "शुरू करें",
    personalizeGuide: "अपनी गाइड को व्यक्तिगत बनाएं",
    welcomeBack: "वापसी पर स्वागत है",
    setupProfile: "अपनी प्रोफ़ाइल बनाएं",
    profileQuestion: "आपको कौन सा विकल्प सबसे अच्छी तरह बताता है?",
    refugeeTitle: "शरणार्थी / नया आने वाला",
    studentTitle: "अंतरराष्ट्रीय छात्र",
    touristTitle: "पर्यटक",
    residentTitle: "निवासी",
    nameQuestion: "आपका नाम क्या है?",
    ageQuestion: "आपकी उम्र कितनी है?",
    cityQuestion: "आप किस शहर में रहते हैं?",
    cityStudyQuestion: "आप किस शहर में पढ़ते हैं?",
    chooseCity: "शहर चुनें",
    touristDestination: "आप कहाँ जा रहे हैं?",
    optional: "वैकल्पिक",
    notDecided: "अभी तय नहीं किया",
    familyQuestion: "क्या आपका परिवार नीदरलैंड्स में है?",
    familyYes: "हाँ, मेरा परिवार है",
    familyNo: "नहीं, मेरा परिवार नहीं है",
    preferredLanguage: "पसंदीदा भाषा",
    profileSummary: "आपकी प्रोफ़ाइल",
    saveProfile: "मेरी गाइड पर जाएँ →",
    completeProfile: "अपनी प्रोफ़ाइल पूरी करें",
    mainDestination: "मुख्य गंतव्य",
  },

  pa: {
    appDescription: "نیدرلینڈز لئی تہاڈا ذاتی اسسٹنٹ",
    editProfile: "پروفائل تبدیل کرو",
    getStarted: "شروع کرو",
    personalizeGuide: "اپنی گائیڈ نوں ذاتی بناؤ",
    welcomeBack: "واپس جی آیاں نوں",
    setupProfile: "اپنا پروفائل بناؤ",
    profileQuestion: "تہاڈے لئی کیہڑا آپشن بہتر اے؟",
    refugeeTitle: "پناہ گزین / نواں آنے والا",
    studentTitle: "بین الاقوامی طالب علم",
    touristTitle: "سیاح",
    residentTitle: "رہائشی",
    nameQuestion: "تہاڈا ناں کی اے؟",
    ageQuestion: "تہاڈی عمر کنی اے؟",
    cityQuestion: "تسی کڑے شہر وچ رہندے او؟",
    cityStudyQuestion: "تسی کڑے شہر وچ پڑھدے او؟",
    chooseCity: "شہر چنو",
    touristDestination: "تسی کتھے جا رہے او؟",
    optional: "اختیاری",
    notDecided: "ہن تک فیصلہ نہیں کیتا",
    familyQuestion: "کی نیدرلینڈز وچ تہاڈا خاندان اے؟",
    familyYes: "ہاں، میرا خاندان اے",
    familyNo: "نہیں، میرا خاندان نہیں اے",
    preferredLanguage: "پسندیدہ زبان",
    profileSummary: "تہاڈا پروفائل",
    saveProfile: "میری گائیڈ تے جاؤ →",
    completeProfile: "اپنا پروفائل مکمل کرو",
    mainDestination: "اہم منزل",
  },

  tr: {
    appDescription: "Hollanda için kişisel asistanınız",
    editProfile: "Profili düzenle",
    getStarted: "Başla",
    personalizeGuide: "Rehberinizi kişiselleştirin",
    welcomeBack: "Tekrar hoş geldiniz",
    setupProfile: "Profilinizi oluşturun",
    profileQuestion: "Sizi en iyi hangisi tanımlıyor?",
    refugeeTitle: "Mülteci / yeni gelen",
    studentTitle: "Uluslararası öğrenci",
    touristTitle: "Turist",
    residentTitle: "Yerleşik",
    nameQuestion: "Adınız nedir?",
    ageQuestion: "Kaç yaşındasınız?",
    cityQuestion: "Hangi şehirde yaşıyorsunuz?",
    cityStudyQuestion: "Hangi şehirde okuyorsunuz?",
    chooseCity: "Şehir seçin",
    touristDestination: "Nereye seyahat ediyorsunuz?",
    optional: "İsteğe bağlı",
    notDecided: "Henüz karar vermedim",
    familyQuestion: "Hollanda'da aileniz var mı?",
    familyYes: "Evet, ailem var",
    familyNo: "Hayır, ailem yok",
    preferredLanguage: "Tercih edilen dil",
    profileSummary: "Profiliniz",
    saveProfile: "Rehberime devam et →",
    completeProfile: "Profilinizi tamamlayın",
    mainDestination: "Ana destinasyon",
  },
};

export const supportedLanguages: {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
}[] = [
  {
    code: "en",
    name: "English",
    nativeName: "English",
  },
  {
    code: "nl",
    name: "Dutch",
    nativeName: "Nederlands",
  },
  {
    code: "ur",
    name: "Urdu",
    nativeName: "اردو",
  },
  {
    code: "ar",
    name: "Arabic",
    nativeName: "العربية",
  },
  {
    code: "hi",
    name: "Hindi",
    nativeName: "हिन्दी",
  },
  {
    code: "pa",
    name: "Punjabi",
    nativeName: "ਪੰਜਾਬੀ",
  },
  {
    code: "tr",
    name: "Turkish",
    nativeName: "Türkçe",
  },
];

export function isSupportedLanguage(
  value: string
): value is SupportedLanguage {
  return (
    SUPPORTED_LANGUAGES as readonly string[]
  ).includes(value);
}

export function getTranslations(
  language: SupportedLanguage
): TranslationKeys {
  return {
    ...english,
    ...translations[language],
  };
}

export function getLanguageName(
  language: SupportedLanguage
): string {
  const found = supportedLanguages.find(
    (item) => item.code === language
  );

  return found?.name ?? "English";
}