"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

import {
  getTranslations,
  isSupportedLanguage,
  type SupportedLanguage,
  type TranslationKeys,
} from "@/lib/translations";

type LanguageContextType = {
  language: SupportedLanguage;
  setLanguage: (language: SupportedLanguage) => void;
  t: TranslationKeys;
};

const LanguageContext =
  createContext<LanguageContextType | undefined>(
    undefined
  );

const STORAGE_KEY =
  "netherlandsGuideLanguage";

export function LanguageProvider({
  children,
}: {
  children: ReactNode;
}) {
  const [language, setLanguageState] =
    useState<SupportedLanguage>("en");

  useEffect(() => {
    try {
      const savedLanguage =
        localStorage.getItem(STORAGE_KEY);

      if (
        savedLanguage &&
        isSupportedLanguage(savedLanguage)
      ) {
        setLanguageState(savedLanguage);
      }
    } catch (error) {
      console.error(
        "Could not load language:",
        error
      );
    }
  }, []);

  function setLanguage(
    newLanguage: SupportedLanguage
  ) {
    setLanguageState(newLanguage);

    try {
      localStorage.setItem(
        STORAGE_KEY,
        newLanguage
      );
    } catch (error) {
      console.error(
        "Could not save language:",
        error
      );
    }
  }

  const t = useMemo(
    () => getTranslations(language),
    [language]
  );

  const value = useMemo(
    () => ({
      language,
      setLanguage,
      t,
    }),
    [language, t]
  );

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context =
    useContext(LanguageContext);

  if (!context) {
    throw new Error(
      "useLanguage must be used inside LanguageProvider"
    );
  }

  return context;
}